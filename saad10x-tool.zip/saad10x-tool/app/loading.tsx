import { Loader2 } from "lucide-react";

export default function Loading() {
  return (
    <div className="container flex min-h-[60vh] items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="h-10 w-10 animate-spin text-cyber-primary" />
        <p className="text-sm text-muted-foreground">Loading secure module…</p>
      </div>
    </div>
  );
}
